import subprocess
import sys

def instalar_dependencias():
    print(" INSTALANDO DEPENDENCIAS DE IA...")
    
    dependencias = [
        "scikit-learn",
        "numpy", 
        "matplotlib",
        "pathlib"
    ]
    
    for dependencia in dependencias:
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", dependencia])
            print(f" {dependencia} instalado")
        except Exception as e:
            print(f" Error con {dependencia}: {e}")
    
    print(" ¡TODAS LAS DEPENDENCIAS INSTALADAS!")
    print("Ahora ejecuta: python python/generador_avanzado.py")

if __name__ == "__main__":
    instalar_dependencias()