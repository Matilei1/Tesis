import random
import json
import time
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from pathlib import Path

class GeneradorGameGenesis:
    def __init__(self):
        self.tipos_tile = {
            0: "empty", 1: "ground", 2: "wall", 
            3: "player", 4: "exit", 5: "enemy", 6: "coin"
        }
        
        self.modelo_calidad = self._entrenar_modelo_calidad()
        print(" IA: Modelo de calidad entrenado")
    
    def _entrenar_modelo_calidad(self):
        X_entrenamiento = []
        y_entrenamiento = []
        
        for _ in range(200):
            densidad_paredes = random.uniform(0.1, 0.7)
            ratio_espacios = random.uniform(0.2, 0.8)
            complejidad = random.uniform(0.1, 0.9)
            calidad = (ratio_espacios * 0.6 + complejidad * 0.3) - (densidad_paredes * 0.4)
            calidad = max(0.1, min(1.0, calidad))
            
            X_entrenamiento.append([densidad_paredes, ratio_espacios, complejidad])
            y_entrenamiento.append(calidad)
        
        modelo = RandomForestRegressor(n_estimators=15, random_state=42)
        modelo.fit(X_entrenamiento, y_entrenamiento)
        return modelo
    
    def generar_nivel_ia(self, estilo="laberinto", dificultad="medio"):

        print(f" Generando nivel {estilo.upper()} - {dificultad.upper()}")
        
        # Configuración basada en estilo y dificultad
        config = self._obtener_configuracion(estilo, dificultad)
        
        # Crear matriz del nivel
        matriz = self._crear_matriz_base(config['ancho'], config['alto'])
        
        # Aplicar algoritmo de generación
        matriz = self._aplicar_generacion_inteligente(matriz, config)
        
        # Colocar elementos clave
        matriz = self._colocar_elementos_clave(matriz)
        
        # Optimizar con IA
        matriz = self._optimizar_con_ia(matriz)
        
        return matriz
    
    def _obtener_configuracion(self, estilo, dificultad):
        """Obtiene configuración basada en estilo y dificultad"""
        configs = {
            "laberinto": {"ancho": 15, "alto": 12, "densidad_paredes": 0.6, "organicidad": 0.8},
            "campo_abierto": {"ancho": 12, "alto": 10, "densidad_paredes": 0.2, "organicidad": 0.3},
            "cueva": {"ancho": 14, "alto": 11, "densidad_paredes": 0.4, "organicidad": 0.9},
            "fortaleza": {"ancho": 16, "alto": 13, "densidad_paredes": 0.7, "organicidad": 0.2}
        }
        
        dificultades = {
            "facil": {"enemigos": 2, "complejidad": 0.3},
            "medio": {"enemigos": 4, "complejidad": 0.6},
            "dificil": {"enemigos": 6, "complejidad": 0.8}
        }
        
        config = configs.get(estilo, configs["laberinto"]).copy()
        config.update(dificultades.get(dificultad, dificultades["medio"]))
        
        return config
    
    def _crear_matriz_base(self, ancho, alto):
        """Crea matriz base con bordes"""
        matriz = [[1 for _ in range(ancho)] for _ in range(alto)]
        
        # Crear bordes
        for i in range(alto):
            matriz[i][0] = 2
            matriz[i][ancho-1] = 2
        for j in range(ancho):
            matriz[0][j] = 2
            matriz[alto-1][j] = 2
        
        return matriz
    
    def _aplicar_generacion_inteligente(self, matriz, config):
        """Aplica generación procedural inteligente"""
        alto, ancho = len(matriz), len(matriz[0])
        
        # Algoritmo de generación mejorado
        for y in range(1, alto-1):
            for x in range(1, ancho-1):
                # Probabilidad basada en configuración
                prob_pared = config['densidad_paredes'] * config['complejidad']
                
                if random.random() < prob_pared:
                    matriz[y][x] = 2  # Pared
                else:
                    matriz[y][x] = 0  # Espacio vacío
                
                # Elementos orgánicos para cuevas
                if config['organicidad'] > 0.7 and random.random() < 0.1:
                    matriz[y][x] = 6  # Moneda/Recurso
        
        return matriz
    
    def _colocar_elementos_clave(self, matriz):
        alto, ancho = len(matriz), len(matriz[0])
        
        # Jugador (esquina superior izquierda)
        for y in range(1, 4):
            for x in range(1, 4):
                if matriz[y][x] == 0:
                    matriz[y][x] = 3
                    break
            else:
                continue
            break
        
        # Salida (esquina inferior derecha)
        for y in range(alto-2, alto-5, -1):
            for x in range(ancho-2, ancho-5, -1):
                if matriz[y][x] == 0:
                    matriz[y][x] = 4
                    break
            else:
                continue
            break
        
        # Enemigos (distribuidos estratégicamente)
        enemigos_colocados = 0
        max_enemigos = 5
        
        while enemigos_colocados < max_enemigos:
            y, x = random.randint(2, alto-3), random.randint(2, ancho-3)
            if matriz[y][x] == 0:  # Solo en espacios vacíos
                matriz[y][x] = 5
                enemigos_colocados += 1
        
        return matriz
    
    def _optimizar_con_ia(self, matriz):
        print(" Optimizando con IA...")
        
        # Extraer características
        caracteristicas = self._extraer_caracteristicas(matriz)
        
        # Predecir calidad
        calidad = self.modelo_calidad.predict([caracteristicas])[0]
        print(f"📊 Calidad IA: {calidad:.1%}")
        
        # Aplicar mejoras si es necesario
        if calidad < 0.6:
            matriz = self._aplicar_mejoras_automaticas(matriz, caracteristicas)
        
        return matriz
    
    def _extraer_caracteristicas(self, matriz):
        alto, ancho = len(matriz), len(matriz[0])
        total_celdas = alto * ancho
        
        paredes = sum(fila.count(2) for fila in matriz)
        espacios = sum(fila.count(0) for fila in matriz)
        
        densidad_paredes = paredes / total_celdas
        ratio_espacios = espacios / total_celdas
        
        # Estimación de complejidad
        complejidad = min(1.0, (densidad_paredes * 0.7 + len(matriz) * 0.3 / 20))
        
        return [densidad_paredes, ratio_espacios, complejidad]
    
    def _aplicar_mejoras_automaticas(self, matriz, caracteristicas):
        """Aplica mejoras automáticas basadas en IA"""
        alto, ancho = len(matriz), len(matriz[0])
        densidad_paredes = caracteristicas[0]
        
        # Si hay demasiadas paredes, remover algunas
        if densidad_paredes > 0.55:
            removidas = 0
            for y in range(2, alto-2):
                for x in range(2, ancho-2):
                    if matriz[y][x] == 2 and random.random() < 0.4:
                        matriz[y][x] = 0
                        removidas += 1
                    if removidas >= 8:
                        break
                if removidas >= 8:
                    break
        
        return matriz
    
    def calcular_metricas_avanzadas(self, matriz):
        """Calcula métricas detalladas del nivel"""
        caracteristicas = self._extraer_caracteristicas(matriz)
        calidad_ia = self.modelo_calidad.predict([caracteristicas])[0]
        
        return {
            "calidad_ia": f"{calidad_ia:.1%}",
            "densidad_paredes": f"{caracteristicas[0]:.1%}",
            "espacio_jugable": f"{caracteristicas[1]:.1%}",
            "complejidad": f"{caracteristicas[2]:.1%}",
            "tamaño": f"{len(matriz[0])}x{len(matriz)}",
            "evaluacion": "Excelente" if calidad_ia > 0.75 else "Buena" if calidad_ia > 0.5 else "Regular"
        }
    
    def guardar_nivel_avanzado(self, matriz, nombre_archivo="nivel_avanzado.json"):
        """Guarda el nivel con metadatos avanzados"""
        datos_nivel = {
            "ancho": len(matriz[0]),
            "alto": len(matriz),
            "tipos_tile": self.tipos_tile,
            "tiles": matriz,
            "metadatos": {
                "generador": "GameGenesis AI Enhanced",
                "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
                "metricas_ia": self.calcular_metricas_avanzadas(matriz),
                "version": "2.0"
            }
        }
        
        # Asegurar que existe el directorio
        Path("levels").mkdir(exist_ok=True)
        ruta_archivo = f"levels/{nombre_archivo}"
        
        with open(ruta_archivo, 'w', encoding='utf-8') as f:
            json.dump(datos_nivel, f, indent=2, ensure_ascii=False)
        
        print(f"💾 Nivel guardado: {ruta_archivo}")
        return ruta_archivo


def ejecutar_gamegenesis():
    print("GAME GENESIS - GENERADOR AVANZADO")
    print("=" * 50)
    
    generador = GeneradorGameGenesis()
    
    # Generar múltiples niveles de ejemplo
    estilos = ["laberinto", "campo_abierto", "cueva", "fortaleza"]
    dificultades = ["facil", "medio", "dificil"]
    
    for estilo in estilos:
        for dificultad in dificultades[:2]:  # Solo fácil y medio para demo
            print(f"\n  Generando: {estilo.upper()} - {dificultad.upper()}")
            print("-" * 35)
            
            nivel = generador.generar_nivel_ia(estilo, dificultad)
            
            metricas = generador.calcular_metricas_avanzadas(nivel)
            for metrica, valor in metricas.items():
                print(f"  📈 {metrica}: {valor}")
            
            nombre_archivo = f"nivel_{estilo}_{dificultad}.json"
            generador.guardar_nivel_avanzado(nivel, nombre_archivo)
            
            print("   Vista previa:")
            for fila in nivel[:6]: 
                preview = "".join("██" if celda == 2 else 
                                "P " if celda == 3 else 
                                "S " if celda == 4 else
                                "E " if celda == 5 else
                                "¢ " if celda == 6 else
                                "  " for celda in fila[:10])
                print(f"    {preview}")
            
            time.sleep(0.5)
    
    print("\n" + "=" * 50)
    print(" GENERACIÓN COMPLETADA!")
    print(" Niveles guardados en carpeta 'levels/'")

if __name__ == "__main__":
    ejecutar_gamegenesis()